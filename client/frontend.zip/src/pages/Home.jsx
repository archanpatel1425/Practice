import React from 'react'
import axios from 'axios'
const Home = () => {
  return (
    <div>
          <div>
              home Page
      </div>
    </div>
  )
}

export default Home
