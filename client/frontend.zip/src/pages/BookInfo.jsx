import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const BookInfo = () => {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [loader, setLoader] = useState(true);

  useEffect(() => {
    axios.get(`http://localhost:5001/bookdata/book_data/${id}`)
      .then(response => {
        setBook(response.data);
        setLoader(false);
      })
      .catch(error => {
        console.error('Error fetching book info:', error);
        setLoader(false);
      });
  }, [id]);

  if (loader) return <h1>Loading...</h1>;

  return (
    <div>
      {book ? (
        <div>
          <h1>{book.bookname}</h1>
          <p>Author: {book.author}</p>
          {/* Add more details as needed */}
        </div>
      ) : (
        <h1>No book found</h1>
      )}
    </div>
  );
};

export default BookInfo;
