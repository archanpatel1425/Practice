import React from 'react'

const AboutPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default AboutPage
