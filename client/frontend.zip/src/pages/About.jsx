import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const About = () => {
  const [res, setRes] = useState([]);
  const [loader, setLoader] = useState(false);
  const navigate = useNavigate();

  const get_data = () => {
    setLoader(true);
    axios.get("http://localhost:5001/bookdata/book_data/1").then((response) => {
      setRes([response.data]);
      setLoader(false);
    });
  };

  const get_all = () => {
    setLoader(true);
    axios.get("http://localhost:5001/bookdata/book_data").then((response) => {
      setRes(response.data);
      setLoader(false);
    });
  };

  const handleMoreClick = (id) => {
    navigate(`/bookinfo/${id}`);
  };

  return (
    <div>
      <button onClick={get_data}>Click here</button>
      <button onClick={get_all}>Get all books</button>
      {loader ? (
        <h1>Loading...</h1>
      ) : (
        res.map((value) => (
          <div key={value.id}>
            <h1>{value.bookname}</h1>
            <button onClick={() => handleMoreClick(value.id)}>More</button>
          </div>
        ))
      )}
    </div>
  );
};

export default About;
